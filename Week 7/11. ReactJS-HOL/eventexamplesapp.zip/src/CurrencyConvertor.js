import React, { useState } from "react";

function CurrencyConvertor() {
  const [amount, setAmount] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const euroAmount = amount * 0.011;
    alert(`Converting to Euro. Amount is ${euroAmount.toFixed(2)}`);
  };

  return (
    <div style={styles.container}>
      <form onSubmit={handleSubmit} style={styles.form}>
        <h2 style={styles.heading}>Currency Converter</h2>

        <label style={styles.label}>Amount:</label>
        <input
          type="number"
          value={amount}
          onChange={(e) => setAmount(e.target.value)}
          style={styles.input}
          required
        />

        <label style={styles.label}>Currency:</label>
        <input
          type="text"
          value="Euro"
          readOnly
          style={styles.input}
        />

        <button type="submit" style={styles.button}>Convert</button>
      </form>
    </div>
  );
}

const styles = {
  container: {
    display: "flex",
    justifyContent: "center",
    marginTop: "30px",
  },
  form: {
    display: "flex",
    flexDirection: "column",
    width: "300px",
    gap: "10px",
  },
  heading: {
    color: "green",
    textAlign: "center",
    marginBottom: "20px",
  },
  label: {
    fontWeight: "bold",
  },
  input: {
    padding: "8px",
    fontSize: "14px",
  },
  button: {
    padding: "10px",
    backgroundColor: "#007bff",
    color: "white",
    fontSize: "16px",
    border: "none",
    cursor: "pointer",
  },
};

export default CurrencyConvertor;
