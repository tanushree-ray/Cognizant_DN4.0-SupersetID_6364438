import React from "react";
import BookDetails from "./components/BookDetails";
import BlogDetails from "./components/BlogDetails";
import CourseDetails from "./components/CourseDetails";
import './App.css';

function App() {
  return (
    <div>
      <h1 style={{ textAlign: 'center' }}>Blogger App</h1>
      <div className="container">
        <div className="section">
          <CourseDetails />
        </div>
        <div className="separator" />
        <div className="section">
          <BookDetails />
        </div>
        <div className="separator" />
        <div className="section">
          <BlogDetails />
        </div>
      </div>
    </div>
  );
}

export default App;
